﻿namespace Program1
{
    partial class programOne
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wallSquareFt = new System.Windows.Forms.Label();
            this.numberOfCoats = new System.Windows.Forms.Label();
            this.gallonsOfPaint = new System.Windows.Forms.Label();
            this.wallSpaceTextBox = new System.Windows.Forms.TextBox();
            this.coatsOfPaintTextBox = new System.Windows.Forms.TextBox();
            this.priceOfPaint = new System.Windows.Forms.TextBox();
            this.outputSqFtLabel = new System.Windows.Forms.Label();
            this.outputPaintLabel = new System.Windows.Forms.Label();
            this.hoursOfLaborLabel = new System.Windows.Forms.Label();
            this.priceOfPaintLabel = new System.Windows.Forms.Label();
            this.priceOfLaborLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.sqFtOutput = new System.Windows.Forms.Label();
            this.gallonsOfPaintOutput = new System.Windows.Forms.Label();
            this.priceOfPaintOutput = new System.Windows.Forms.Label();
            this.hoursLaborOutput = new System.Windows.Forms.Label();
            this.priceOfLaborOutput = new System.Windows.Forms.Label();
            this.totalOutput = new System.Windows.Forms.Label();
            this.calculateTotalButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wallSquareFt
            // 
            this.wallSquareFt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.wallSquareFt.Location = new System.Drawing.Point(39, 40);
            this.wallSquareFt.Name = "wallSquareFt";
            this.wallSquareFt.Size = new System.Drawing.Size(300, 23);
            this.wallSquareFt.TabIndex = 0;
            this.wallSquareFt.Text = "Please enter square feet of wall space:";
            // 
            // numberOfCoats
            // 
            this.numberOfCoats.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.numberOfCoats.Location = new System.Drawing.Point(43, 82);
            this.numberOfCoats.Name = "numberOfCoats";
            this.numberOfCoats.Size = new System.Drawing.Size(296, 20);
            this.numberOfCoats.TabIndex = 1;
            this.numberOfCoats.Text = "Please enter number of coats of paint:";
            // 
            // gallonsOfPaint
            // 
            this.gallonsOfPaint.AutoSize = true;
            this.gallonsOfPaint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.gallonsOfPaint.Location = new System.Drawing.Point(12, 119);
            this.gallonsOfPaint.Name = "gallonsOfPaint";
            this.gallonsOfPaint.Size = new System.Drawing.Size(327, 20);
            this.gallonsOfPaint.TabIndex = 2;
            this.gallonsOfPaint.Text = "Please enter the price for paint (by gallon):";
            // 
            // wallSpaceTextBox
            // 
            this.wallSpaceTextBox.Location = new System.Drawing.Point(345, 43);
            this.wallSpaceTextBox.Name = "wallSpaceTextBox";
            this.wallSpaceTextBox.Size = new System.Drawing.Size(171, 20);
            this.wallSpaceTextBox.TabIndex = 3;
            // 
            // coatsOfPaintTextBox
            // 
            this.coatsOfPaintTextBox.Location = new System.Drawing.Point(345, 84);
            this.coatsOfPaintTextBox.Name = "coatsOfPaintTextBox";
            this.coatsOfPaintTextBox.Size = new System.Drawing.Size(171, 20);
            this.coatsOfPaintTextBox.TabIndex = 4;
            // 
            // priceOfPaint
            // 
            this.priceOfPaint.Location = new System.Drawing.Point(345, 121);
            this.priceOfPaint.Name = "priceOfPaint";
            this.priceOfPaint.Size = new System.Drawing.Size(171, 20);
            this.priceOfPaint.TabIndex = 5;
            // 
            // outputSqFtLabel
            // 
            this.outputSqFtLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.outputSqFtLabel.Location = new System.Drawing.Point(56, 204);
            this.outputSqFtLabel.Name = "outputSqFtLabel";
            this.outputSqFtLabel.Size = new System.Drawing.Size(106, 23);
            this.outputSqFtLabel.TabIndex = 6;
            this.outputSqFtLabel.Text = "Square Feet:";
            // 
            // outputPaintLabel
            // 
            this.outputPaintLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.outputPaintLabel.Location = new System.Drawing.Point(28, 243);
            this.outputPaintLabel.Name = "outputPaintLabel";
            this.outputPaintLabel.Size = new System.Drawing.Size(134, 23);
            this.outputPaintLabel.TabIndex = 7;
            this.outputPaintLabel.Text = "Gallons of Paint:";
            // 
            // hoursOfLaborLabel
            // 
            this.hoursOfLaborLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.hoursOfLaborLabel.Location = new System.Drawing.Point(101, 323);
            this.hoursOfLaborLabel.Name = "hoursOfLaborLabel";
            this.hoursOfLaborLabel.Size = new System.Drawing.Size(61, 23);
            this.hoursOfLaborLabel.TabIndex = 8;
            this.hoursOfLaborLabel.Text = "Hours:";
            // 
            // priceOfPaintLabel
            // 
            this.priceOfPaintLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.priceOfPaintLabel.Location = new System.Drawing.Point(47, 283);
            this.priceOfPaintLabel.Name = "priceOfPaintLabel";
            this.priceOfPaintLabel.Size = new System.Drawing.Size(115, 23);
            this.priceOfPaintLabel.TabIndex = 9;
            this.priceOfPaintLabel.Text = "Price of Paint:";
            // 
            // priceOfLaborLabel
            // 
            this.priceOfLaborLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.priceOfLaborLabel.Location = new System.Drawing.Point(41, 360);
            this.priceOfLaborLabel.Name = "priceOfLaborLabel";
            this.priceOfLaborLabel.Size = new System.Drawing.Size(121, 23);
            this.priceOfLaborLabel.TabIndex = 10;
            this.priceOfLaborLabel.Text = "Price of Labor:";
            // 
            // totalLabel
            // 
            this.totalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.totalLabel.Location = new System.Drawing.Point(111, 399);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(51, 23);
            this.totalLabel.TabIndex = 11;
            this.totalLabel.Text = "Total:";
            // 
            // sqFtOutput
            // 
            this.sqFtOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqFtOutput.Location = new System.Drawing.Point(170, 208);
            this.sqFtOutput.Name = "sqFtOutput";
            this.sqFtOutput.Size = new System.Drawing.Size(189, 18);
            this.sqFtOutput.TabIndex = 12;
            // 
            // gallonsOfPaintOutput
            // 
            this.gallonsOfPaintOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsOfPaintOutput.Location = new System.Drawing.Point(170, 248);
            this.gallonsOfPaintOutput.Name = "gallonsOfPaintOutput";
            this.gallonsOfPaintOutput.Size = new System.Drawing.Size(189, 18);
            this.gallonsOfPaintOutput.TabIndex = 13;
            // 
            // priceOfPaintOutput
            // 
            this.priceOfPaintOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.priceOfPaintOutput.Location = new System.Drawing.Point(170, 288);
            this.priceOfPaintOutput.Name = "priceOfPaintOutput";
            this.priceOfPaintOutput.Size = new System.Drawing.Size(189, 18);
            this.priceOfPaintOutput.TabIndex = 14;
            // 
            // hoursLaborOutput
            // 
            this.hoursLaborOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hoursLaborOutput.Location = new System.Drawing.Point(170, 328);
            this.hoursLaborOutput.Name = "hoursLaborOutput";
            this.hoursLaborOutput.Size = new System.Drawing.Size(189, 18);
            this.hoursLaborOutput.TabIndex = 15;
            // 
            // priceOfLaborOutput
            // 
            this.priceOfLaborOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.priceOfLaborOutput.Location = new System.Drawing.Point(170, 365);
            this.priceOfLaborOutput.Name = "priceOfLaborOutput";
            this.priceOfLaborOutput.Size = new System.Drawing.Size(189, 18);
            this.priceOfLaborOutput.TabIndex = 16;
            // 
            // totalOutput
            // 
            this.totalOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalOutput.Location = new System.Drawing.Point(170, 403);
            this.totalOutput.Name = "totalOutput";
            this.totalOutput.Size = new System.Drawing.Size(189, 18);
            this.totalOutput.TabIndex = 17;
            // 
            // calculateTotalButton
            // 
            this.calculateTotalButton.Location = new System.Drawing.Point(172, 463);
            this.calculateTotalButton.Name = "calculateTotalButton";
            this.calculateTotalButton.Size = new System.Drawing.Size(184, 39);
            this.calculateTotalButton.TabIndex = 18;
            this.calculateTotalButton.Text = "Calculate Total";
            this.calculateTotalButton.UseVisualStyleBackColor = true;
            this.calculateTotalButton.Click += new System.EventHandler(this.calculateTotalButton_Click);
            // 
            // programOne
            // 
            this.AcceptButton = this.calculateTotalButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 534);
            this.Controls.Add(this.calculateTotalButton);
            this.Controls.Add(this.totalOutput);
            this.Controls.Add(this.priceOfLaborOutput);
            this.Controls.Add(this.hoursLaborOutput);
            this.Controls.Add(this.priceOfPaintOutput);
            this.Controls.Add(this.gallonsOfPaintOutput);
            this.Controls.Add(this.sqFtOutput);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.priceOfLaborLabel);
            this.Controls.Add(this.priceOfPaintLabel);
            this.Controls.Add(this.hoursOfLaborLabel);
            this.Controls.Add(this.outputPaintLabel);
            this.Controls.Add(this.outputSqFtLabel);
            this.Controls.Add(this.priceOfPaint);
            this.Controls.Add(this.coatsOfPaintTextBox);
            this.Controls.Add(this.wallSpaceTextBox);
            this.Controls.Add(this.gallonsOfPaint);
            this.Controls.Add(this.numberOfCoats);
            this.Controls.Add(this.wallSquareFt);
            this.Name = "programOne";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wallSquareFt;
        private System.Windows.Forms.Label numberOfCoats;
        private System.Windows.Forms.Label gallonsOfPaint;
        private System.Windows.Forms.TextBox wallSpaceTextBox;
        private System.Windows.Forms.TextBox coatsOfPaintTextBox;
        private System.Windows.Forms.TextBox priceOfPaint;
        private System.Windows.Forms.Label outputSqFtLabel;
        private System.Windows.Forms.Label outputPaintLabel;
        private System.Windows.Forms.Label hoursOfLaborLabel;
        private System.Windows.Forms.Label priceOfPaintLabel;
        private System.Windows.Forms.Label priceOfLaborLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label sqFtOutput;
        private System.Windows.Forms.Label gallonsOfPaintOutput;
        private System.Windows.Forms.Label priceOfPaintOutput;
        private System.Windows.Forms.Label hoursLaborOutput;
        private System.Windows.Forms.Label priceOfLaborOutput;
        private System.Windows.Forms.Label totalOutput;
        private System.Windows.Forms.Button calculateTotalButton;
    }
}

