﻿namespace Program_4
{
    partial class program4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.originZipTextBox = new System.Windows.Forms.TextBox();
            this.destinationZipTextBox = new System.Windows.Forms.TextBox();
            this.lengthTextBox = new System.Windows.Forms.TextBox();
            this.widthTextBox = new System.Windows.Forms.TextBox();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.packageListBox = new System.Windows.Forms.ListBox();
            this.detailsButton = new System.Windows.Forms.Button();
            this.fromUoflButton = new System.Windows.Forms.Button();
            this.toUoflButton = new System.Windows.Forms.Button();
            this.originZipLabel = new System.Windows.Forms.Label();
            this.destinationZipLabel = new System.Windows.Forms.Label();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.widthLabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.weightLabel = new System.Windows.Forms.Label();
            this.calculatePriceButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // originZipTextBox
            // 
            this.originZipTextBox.Location = new System.Drawing.Point(114, 13);
            this.originZipTextBox.Name = "originZipTextBox";
            this.originZipTextBox.Size = new System.Drawing.Size(116, 20);
            this.originZipTextBox.TabIndex = 0;
            // 
            // destinationZipTextBox
            // 
            this.destinationZipTextBox.Location = new System.Drawing.Point(114, 38);
            this.destinationZipTextBox.Name = "destinationZipTextBox";
            this.destinationZipTextBox.Size = new System.Drawing.Size(116, 20);
            this.destinationZipTextBox.TabIndex = 1;
            // 
            // lengthTextBox
            // 
            this.lengthTextBox.Location = new System.Drawing.Point(114, 64);
            this.lengthTextBox.Name = "lengthTextBox";
            this.lengthTextBox.Size = new System.Drawing.Size(116, 20);
            this.lengthTextBox.TabIndex = 2;
            // 
            // widthTextBox
            // 
            this.widthTextBox.Location = new System.Drawing.Point(114, 90);
            this.widthTextBox.Name = "widthTextBox";
            this.widthTextBox.Size = new System.Drawing.Size(116, 20);
            this.widthTextBox.TabIndex = 3;
            // 
            // heightTextBox
            // 
            this.heightTextBox.Location = new System.Drawing.Point(114, 116);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(116, 20);
            this.heightTextBox.TabIndex = 4;
            // 
            // weightTextBox
            // 
            this.weightTextBox.Location = new System.Drawing.Point(114, 142);
            this.weightTextBox.Name = "weightTextBox";
            this.weightTextBox.Size = new System.Drawing.Size(116, 20);
            this.weightTextBox.TabIndex = 5;
            // 
            // packageListBox
            // 
            this.packageListBox.FormattingEnabled = true;
            this.packageListBox.Location = new System.Drawing.Point(236, 12);
            this.packageListBox.Name = "packageListBox";
            this.packageListBox.Size = new System.Drawing.Size(327, 199);
            this.packageListBox.TabIndex = 6;
            // 
            // detailsButton
            // 
            this.detailsButton.Location = new System.Drawing.Point(569, 12);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(116, 64);
            this.detailsButton.TabIndex = 7;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // fromUoflButton
            // 
            this.fromUoflButton.Location = new System.Drawing.Point(569, 95);
            this.fromUoflButton.Name = "fromUoflButton";
            this.fromUoflButton.Size = new System.Drawing.Size(116, 48);
            this.fromUoflButton.TabIndex = 9;
            this.fromUoflButton.Text = "Send from UofL";
            this.fromUoflButton.UseVisualStyleBackColor = true;
            this.fromUoflButton.Click += new System.EventHandler(this.fromUoflButton_Click);
            // 
            // toUoflButton
            // 
            this.toUoflButton.Location = new System.Drawing.Point(569, 162);
            this.toUoflButton.Name = "toUoflButton";
            this.toUoflButton.Size = new System.Drawing.Size(116, 49);
            this.toUoflButton.TabIndex = 10;
            this.toUoflButton.Text = "Send to UofL";
            this.toUoflButton.UseVisualStyleBackColor = true;
            this.toUoflButton.Click += new System.EventHandler(this.toUoflButton_Click);
            // 
            // originZipLabel
            // 
            this.originZipLabel.Location = new System.Drawing.Point(2, 12);
            this.originZipLabel.Name = "originZipLabel";
            this.originZipLabel.Size = new System.Drawing.Size(106, 20);
            this.originZipLabel.TabIndex = 11;
            this.originZipLabel.Text = "Origin Zip:";
            this.originZipLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // destinationZipLabel
            // 
            this.destinationZipLabel.Location = new System.Drawing.Point(2, 38);
            this.destinationZipLabel.Name = "destinationZipLabel";
            this.destinationZipLabel.Size = new System.Drawing.Size(106, 20);
            this.destinationZipLabel.TabIndex = 12;
            this.destinationZipLabel.Text = "Destination Zip:";
            this.destinationZipLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lengthLabel
            // 
            this.lengthLabel.Location = new System.Drawing.Point(2, 64);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(106, 20);
            this.lengthLabel.TabIndex = 13;
            this.lengthLabel.Text = "Length:";
            this.lengthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // widthLabel
            // 
            this.widthLabel.Location = new System.Drawing.Point(2, 90);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(106, 20);
            this.widthLabel.TabIndex = 14;
            this.widthLabel.Text = "Width:";
            this.widthLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // heightLabel
            // 
            this.heightLabel.Location = new System.Drawing.Point(2, 116);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(106, 20);
            this.heightLabel.TabIndex = 15;
            this.heightLabel.Text = "Height:";
            this.heightLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // weightLabel
            // 
            this.weightLabel.Location = new System.Drawing.Point(2, 142);
            this.weightLabel.Name = "weightLabel";
            this.weightLabel.Size = new System.Drawing.Size(106, 20);
            this.weightLabel.TabIndex = 16;
            this.weightLabel.Text = "Weight:";
            this.weightLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // calculatePriceButton
            // 
            this.calculatePriceButton.Location = new System.Drawing.Point(114, 166);
            this.calculatePriceButton.Name = "calculatePriceButton";
            this.calculatePriceButton.Size = new System.Drawing.Size(116, 46);
            this.calculatePriceButton.TabIndex = 17;
            this.calculatePriceButton.Text = "Calculate Price";
            this.calculatePriceButton.UseVisualStyleBackColor = true;
            this.calculatePriceButton.Click += new System.EventHandler(this.calculatePriceButton_Click);
            // 
            // program4Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 226);
            this.Controls.Add(this.calculatePriceButton);
            this.Controls.Add(this.weightLabel);
            this.Controls.Add(this.heightLabel);
            this.Controls.Add(this.widthLabel);
            this.Controls.Add(this.lengthLabel);
            this.Controls.Add(this.destinationZipLabel);
            this.Controls.Add(this.originZipLabel);
            this.Controls.Add(this.toUoflButton);
            this.Controls.Add(this.fromUoflButton);
            this.Controls.Add(this.detailsButton);
            this.Controls.Add(this.packageListBox);
            this.Controls.Add(this.weightTextBox);
            this.Controls.Add(this.heightTextBox);
            this.Controls.Add(this.widthTextBox);
            this.Controls.Add(this.lengthTextBox);
            this.Controls.Add(this.destinationZipTextBox);
            this.Controls.Add(this.originZipTextBox);
            this.Name = "program4Form";
            this.Text = "Program 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox originZipTextBox;
        private System.Windows.Forms.TextBox destinationZipTextBox;
        private System.Windows.Forms.TextBox lengthTextBox;
        private System.Windows.Forms.TextBox widthTextBox;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.ListBox packageListBox;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.Button fromUoflButton;
        private System.Windows.Forms.Button toUoflButton;
        private System.Windows.Forms.Label originZipLabel;
        private System.Windows.Forms.Label destinationZipLabel;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.Label weightLabel;
        private System.Windows.Forms.Button calculatePriceButton;
    }
}

