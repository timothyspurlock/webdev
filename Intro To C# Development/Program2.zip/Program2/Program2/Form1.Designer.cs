﻿namespace Program2
{
    partial class program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.collegeYearGroup = new System.Windows.Forms.GroupBox();
            this.seniorRadioButton = new System.Windows.Forms.RadioButton();
            this.juniorRadioButton = new System.Windows.Forms.RadioButton();
            this.sophomoreRadioButton = new System.Windows.Forms.RadioButton();
            this.freshmanRadioButton = new System.Windows.Forms.RadioButton();
            this.registrarOutput = new System.Windows.Forms.Label();
            this.registrationButton = new System.Windows.Forms.Button();
            this.regisDateLabel = new System.Windows.Forms.Label();
            this.collegeYearGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(177, 16);
            this.lastNameTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(188, 22);
            this.lastNameTextBox.TabIndex = 0;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.Location = new System.Drawing.Point(16, 16);
            this.lastNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(153, 25);
            this.lastNameLabel.TabIndex = 1;
            this.lastNameLabel.Text = "Enter Your Last Name:";
            this.lastNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // collegeYearGroup
            // 
            this.collegeYearGroup.Controls.Add(this.seniorRadioButton);
            this.collegeYearGroup.Controls.Add(this.juniorRadioButton);
            this.collegeYearGroup.Controls.Add(this.sophomoreRadioButton);
            this.collegeYearGroup.Controls.Add(this.freshmanRadioButton);
            this.collegeYearGroup.Location = new System.Drawing.Point(16, 73);
            this.collegeYearGroup.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.collegeYearGroup.Name = "collegeYearGroup";
            this.collegeYearGroup.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.collegeYearGroup.Size = new System.Drawing.Size(145, 140);
            this.collegeYearGroup.TabIndex = 2;
            this.collegeYearGroup.TabStop = false;
            this.collegeYearGroup.Text = "Select Year";
            // 
            // seniorRadioButton
            // 
            this.seniorRadioButton.AutoSize = true;
            this.seniorRadioButton.Location = new System.Drawing.Point(16, 109);
            this.seniorRadioButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.seniorRadioButton.Name = "seniorRadioButton";
            this.seniorRadioButton.Size = new System.Drawing.Size(70, 21);
            this.seniorRadioButton.TabIndex = 3;
            this.seniorRadioButton.TabStop = true;
            this.seniorRadioButton.Text = "Senior";
            this.seniorRadioButton.UseVisualStyleBackColor = true;
            // 
            // juniorRadioButton
            // 
            this.juniorRadioButton.AutoSize = true;
            this.juniorRadioButton.Location = new System.Drawing.Point(16, 81);
            this.juniorRadioButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.juniorRadioButton.Name = "juniorRadioButton";
            this.juniorRadioButton.Size = new System.Drawing.Size(68, 21);
            this.juniorRadioButton.TabIndex = 2;
            this.juniorRadioButton.TabStop = true;
            this.juniorRadioButton.Text = "Junior";
            this.juniorRadioButton.UseVisualStyleBackColor = true;
            // 
            // sophomoreRadioButton
            // 
            this.sophomoreRadioButton.AutoSize = true;
            this.sophomoreRadioButton.Location = new System.Drawing.Point(16, 53);
            this.sophomoreRadioButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sophomoreRadioButton.Name = "sophomoreRadioButton";
            this.sophomoreRadioButton.Size = new System.Drawing.Size(102, 21);
            this.sophomoreRadioButton.TabIndex = 1;
            this.sophomoreRadioButton.TabStop = true;
            this.sophomoreRadioButton.Text = "Sophomore";
            this.sophomoreRadioButton.UseVisualStyleBackColor = true;
            // 
            // freshmanRadioButton
            // 
            this.freshmanRadioButton.AutoSize = true;
            this.freshmanRadioButton.Checked = true;
            this.freshmanRadioButton.Location = new System.Drawing.Point(16, 25);
            this.freshmanRadioButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.freshmanRadioButton.Name = "freshmanRadioButton";
            this.freshmanRadioButton.Size = new System.Drawing.Size(92, 21);
            this.freshmanRadioButton.TabIndex = 0;
            this.freshmanRadioButton.TabStop = true;
            this.freshmanRadioButton.Text = "Freshman";
            this.freshmanRadioButton.UseVisualStyleBackColor = true;
            // 
            // registrarOutput
            // 
            this.registrarOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.registrarOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registrarOutput.Location = new System.Drawing.Point(177, 169);
            this.registrarOutput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.registrarOutput.Name = "registrarOutput";
            this.registrarOutput.Size = new System.Drawing.Size(189, 44);
            this.registrarOutput.TabIndex = 4;
            this.registrarOutput.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // registrationButton
            // 
            this.registrationButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.registrationButton.Location = new System.Drawing.Point(177, 59);
            this.registrationButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.registrationButton.Name = "registrationButton";
            this.registrationButton.Size = new System.Drawing.Size(189, 59);
            this.registrationButton.TabIndex = 5;
            this.registrationButton.Text = "Find your registration time";
            this.registrationButton.UseVisualStyleBackColor = true;
            this.registrationButton.Click += new System.EventHandler(this.registrationButton_Click);
            // 
            // regisDateLabel
            // 
            this.regisDateLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.regisDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regisDateLabel.Location = new System.Drawing.Point(177, 122);
            this.regisDateLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.regisDateLabel.Name = "regisDateLabel";
            this.regisDateLabel.Size = new System.Drawing.Size(189, 44);
            this.regisDateLabel.TabIndex = 6;
            this.regisDateLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // program2
            // 
            this.AcceptButton = this.registrationButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 249);
            this.Controls.Add(this.regisDateLabel);
            this.Controls.Add(this.registrationButton);
            this.Controls.Add(this.registrarOutput);
            this.Controls.Add(this.collegeYearGroup);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "program2";
            this.Text = "Program 2";
            this.collegeYearGroup.ResumeLayout(false);
            this.collegeYearGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.GroupBox collegeYearGroup;
        private System.Windows.Forms.RadioButton seniorRadioButton;
        private System.Windows.Forms.RadioButton juniorRadioButton;
        private System.Windows.Forms.RadioButton sophomoreRadioButton;
        private System.Windows.Forms.RadioButton freshmanRadioButton;
        private System.Windows.Forms.Label registrarOutput;
        private System.Windows.Forms.Button registrationButton;
        private System.Windows.Forms.Label regisDateLabel;
    }
}

