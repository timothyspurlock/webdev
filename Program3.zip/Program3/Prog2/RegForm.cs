﻿// Program 3
// CIS 199-01
// Due: 4/13/17
// By: A2598

// This application calculates the earliest registration date
// and time for an undergraduate student given their class standing
// and last name. This application uses arrays to calculate the registration
// date and time for each student.
// Decisions based on UofL Fall/Summer 2017 Priority Registration Schedule

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        // Find and display earliest registration time
        private void findRegTimeBtn_Click(object sender, EventArgs e)
        {
            const string DAY1 = "March 29";  // 1st day of registration
            const string DAY2 = "March 30";  // 2nd day of registration
            const string DAY3 = "March 31";  // 3rd day of registration
            const string DAY4 = "April 3";   // 4th day of registration
            const string DAY5 = "April 4";   // 5th day of registration
            const string DAY6 = "April 5";   // 6th day of registration

            const string TIME1 = "8:30 AM";  // 1st time block
            const string TIME2 = "10:00 AM"; // 2nd time block
            const string TIME3 = "11:30 AM"; // 3rd time block
            const string TIME4 = "2:00 PM";  // 4th time block
            const string TIME5 = "4:00 PM";  // 5th time block

            string lastNameStr;       // Entered last name
            char lastNameLetterCh;    // First letter of last name, as char
            string dateStr = "Error"; // Holds date of registration
            string timeStr = "Error"; // Holds time of registration
            bool isUpperClass;        // Upperclass or not?

            char[] letter1 = {'D','I','O','S','Z'};//Array for the senior/junior group of students
            char[] letter2 = { 'B', 'D', 'F', 'I', 'L', 'O', 'Q', 'S', 'V', 'Z' };//Array for the sophmore/freshman group of students
            string[] time1 = { TIME3, TIME4, TIME5, TIME1, TIME2 }; //time slots for juniors and seniors
            string[] time2 = { TIME5, TIME1, TIME2, TIME3, TIME4, TIME5, TIME1, TIME2, TIME3, TIME4 };//time slots for freshman and sophmores
            bool found = false; // boolean for finding a character 
            int index = 0; //index of the array
            lastNameStr = lastNameTxt.Text;
            
            if (lastNameStr.Length > 0) // Empty string?
            {
                lastNameLetterCh = lastNameStr[0];   // First char of last name
                lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case


                //Pre-Condition: Must have a button checked and have a valid last name entered. No numbers or special characters
                //Post-Condition: User will be given a date and time for their name they type and for what button they press.
                if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                {
                    isUpperClass = (seniorRBtn.Checked || juniorRBtn.Checked);

                    // Juniors and Seniors share same schedule but different days
                    if (isUpperClass)
                    {
                        if (seniorRBtn.Checked)
                        {
                            dateStr = DAY1;
                        }
                        else // Must be juniors
                        {
                            dateStr = DAY2;
                        }
                        
                        while (index < letter1.Length && !found) //while loop makes index less than the length of the first letter array and not found
                        {
                            if (lastNameLetterCh <= letter1[index]) //checks the character to the array
                            {
                                found = true;

                            }
                            else
                                index++;
                        }
                        if (found)
                        {
                            timeStr = time1[index]; //if the character is found within the array, it sets a time corresponding to the letter array
                        }
                    }
                    // Sophomores and Freshmen
                    else // Must be soph/fresh
                    {
                        if (sophomoreRBtn.Checked)
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY4;
                            else // All other letters on previous day
                                dateStr = DAY3;
                        }
                        else // must be freshman
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY6;
                            else // All other letters on previous day
                                dateStr = DAY5;
                        }
                        while (index < letter2.Length && !found)
                        {
                            if (lastNameLetterCh <= letter2[index]) //while loop makes index less than the length of the first letter array and not found
                            {
                                found = true;

                            }
                            else
                                index++;
                        }
                        if (found)
                        {
                            timeStr = time2[index]; //if the character is found within the letter2 array, it sets a time from time2 which corresponds to the letter array
                        }
                        
                    }

                    // Output results
                    dateTimeLbl.Text = dateStr + " at " + timeStr;
                }
                else // First char not a letter
                    MessageBox.Show("Make sure last name starts with a letter");
            }
            else // Empty textbox
                MessageBox.Show("Enter a last name!");
        }
    }
}
