﻿/* Grade ID: A2598
 * CIS-199-01
 * Program 2
 * Due March 9th
 * This program allows a user to type in his last name and select a button based on their year in college
 * which then will output a day and also a time of registration.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class program2 : Form
    {
        public program2()
        {
            InitializeComponent();
        }
        private void registrationButton_Click(object sender, EventArgs e)
        {
            char letter; //creation of the char variable
            letter = Char.ToLower(lastNameTextBox.Text[0]); //casting the last name text box and assigning it to the letter variable. [0] means it looks for the first letter in the text box

            //Using constants to set for days of registration. 
            //Sophomore2 and Freshman2 days are there because the classes
            //are split between 2 dates in times for certain letters
            const string SENIOR_DATE = "March 29th";
            const string JUNIOR_DATE = "March 30th";
            const string SOPHOMORE_DATE = "March 31st";
            const string SOPHOMORE_DATE2 = "April 3rd";
            const string FRESHMAN_DATE = "April 4th";
            const string FRESHMAN_DATE2 = "April 5th";
            //Constants set for the only possible registration times
            const string FIRST_TIME = "8:30";
            const string SECOND_TIME = "10:00";
            const string THIRD_TIME = "11:30";
            const string FOURTH_TIME = "2:00";
            const string FIFTH_TIME = "4:00";

            if (seniorRadioButton.Checked) //This starts off checking if the senior button is checked
            {
                regisDateLabel.Text = SENIOR_DATE; //if it is checked, then the top label will output a day
            }
            else if (juniorRadioButton.Checked)//if the senior button is not checked it will check for the junior button
            {
                regisDateLabel.Text = JUNIOR_DATE; //if it is checked, then the top label will output a day
            }
            else if (sophomoreRadioButton.Checked && (letter >= 'p' && letter <= 'z' || letter >= 'a' && letter <= 'b')) //if the junior button is checked it will check for the sophomore button and if the last name textbox has certain first letters in the last name
            {
                regisDateLabel.Text = SOPHOMORE_DATE; //if it is checked and letters are correct, then the top label will output a day
            }
            else if (sophomoreRadioButton.Checked && letter >= 'c' && letter <= 'o') //if the sophomore button is checked but the letters arent correct it will check another pair.
            {
                regisDateLabel.Text = SOPHOMORE_DATE2; //if it is checked and letters are correct, then the top label will output a day
            }
            else if (freshmanRadioButton.Checked && (letter >= 'p' && letter <= 'z' || letter >= 'a' && letter <= 'b')) //if both sophomore tests fail it will check the freshman button and the letters for the first date
            {
                regisDateLabel.Text = FRESHMAN_DATE;  //if it is checked and letters are correct, then the top label will output a day
            }
            else
                regisDateLabel.Text = FRESHMAN_DATE2; //if the letters aren't correct it will output the second date referring to the second set of letters


            //Start of Senior and Junior slot times
            if (seniorRadioButton.Checked || juniorRadioButton.Checked) //This will test the what the letters are within the letter char variable
            {
                if (letter <= 'd') //if the letters are from A-D, the 3rd time will be outputted
                {
                    registrarOutput.Text = "At " + THIRD_TIME; //this sets up the output for the first label (below the last name textbox)
                }
                else if (letter <= 'i') //if the letters are from E-I, the 4th time will be outputted
                {
                    registrarOutput.Text = "At " + FOURTH_TIME; //this sets up the output for the first label (below the last name textbox)
                }
                else if (letter <= 'o')// if the letters are from J-O, the 5th time will be outputted
                {
                    registrarOutput.Text = "At " + FIFTH_TIME; //this sets up the output for the first label (below the last name textbox)
                }
                else if (letter <= 's')//if the letters are from P-S, the 1st time will be outputted
                {
                    registrarOutput.Text = "At " + FIRST_TIME; //this sets up the output for the first label (below the last name textbox)
                }
                else //if the letters are from T-Z, the 2nd time will be outputted
                {
                    registrarOutput.Text = "At " + SECOND_TIME; //this sets up the output for the first label (below the last name textbox)
                }
            }//Start of Sophomore and Freshman slot times
            else if (sophomoreRadioButton.Checked || freshmanRadioButton.Checked) //checks if either sophomore or freshman buttons are checked.
            {
                if (letter >= 'p' && letter <= 'q' || letter >= 'c' && letter <= 'd') //if letters are from P-Q or C-D, the first time will be outputted 
                {
                    registrarOutput.Text = "At " + FIRST_TIME;
                }
                else if (letter >= 'r' && letter <= 's' || letter >= 'e' && letter <= 'f')//if letters are from R-S or E-F, the second time will be outputted
                {
                    registrarOutput.Text = "At " + SECOND_TIME;
                }
                else if (letter >= 't' && letter <= 'v' || letter >= 'g' && letter <= 'i') //if the letters are from T-V or G-I, the third time will be outputted
                {
                    registrarOutput.Text = "At " + THIRD_TIME;
                }
                else if (letter >= 'w' && letter <= 'z' || letter >= 'j' && letter <= 'l')//if the letters are from W-Z or J-L, the fourth time will be outputted
                {
                    registrarOutput.Text = "At " + FOURTH_TIME;
                }
                else //if nothing else matches the test in this section, it will output the fith time which is A-B or M-O
                {
                    registrarOutput.Text = "At " + FIFTH_TIME; //last timing available. What it would be looking for is (letter >= 'a' && letter <= 'b' || letter >= 'm' && letter <= 'o')
                }

            }

        }
    }
}