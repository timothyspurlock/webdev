﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_4
{
    public partial class program4Form : Form
    {        
        //Creates list for the groundpackage
        private List<GroundPackage> groundPackageList = new List<GroundPackage>();

        //Declares Default values
        public const double DEFAULT_VALUE = 1.0; 
        public const int DEFAULT_ORGZIP = 40202;
        public const int DEFAULT_DESTZIP = 90210;
        public const int UOFL_ZIP = 40292;


        public program4Form()
        {
            InitializeComponent();
        }

        //Validation for the pacakge
        private bool ValidatePackageData(out double length, out double width, out double height, out double weight, out int originZip, out int destinationZip)
        {
            bool isValid = false; //declares bool
            //sets variables to a default value
            length = DEFAULT_VALUE;
            width = DEFAULT_VALUE;
            height = DEFAULT_VALUE;
            weight = DEFAULT_VALUE;
            originZip = DEFAULT_ORGZIP;
            destinationZip = DEFAULT_DESTZIP;

            //Parsing data. If parse data works, then isValid is set to True
            if (double.TryParse(lengthTextBox.Text, out length) && double.TryParse(widthTextBox.Text, out width) &&
               double.TryParse(heightTextBox.Text, out height) && double.TryParse(weightTextBox.Text, out weight) && int.TryParse(originZipTextBox.Text, out originZip) &&
               int.TryParse(destinationZipTextBox.Text, out destinationZip))
            {
               isValid = true;
            }
            else
            {
                MessageBox.Show("Please check values. Numbers must be positive!"); //If validation fails, user will be prompted with an error
            }

            return isValid; //return isValid at the end
        }
       
        //Precondition: Button must be clicked and text box values must be greater than zero
        //Postcondition: Cost of package will be returned and details also set in list box

        private void calculatePriceButton_Click(object sender, EventArgs e)
        {
            GroundPackage myPackage; //declares myPackage
            //sets package properties
            double packageLength;
            double packageWidth;
            double packageHeight;
            double packageWeight;
            int theOriginZip;
            int theDestinationZip;

            if (ValidatePackageData(out packageLength, out packageWidth, out packageHeight, out packageWeight, out theOriginZip, out theDestinationZip))
            {
                //Only Create when data is validated

                myPackage = new GroundPackage(packageLength, packageWidth, packageHeight, packageWeight, theOriginZip, theDestinationZip); //new ground package is created

                //myPackage is added to the list of ground packages
                groundPackageList.Add(myPackage);

                //my package is set in the list box and is set as a calculated price with the concatenated ToString set
                packageListBox.Items.Add(myPackage.CalcCost().ToString("C"));

                //Clears text boxes for re-use
                lengthTextBox.Clear();
                widthTextBox.Clear();
                heightTextBox.Clear();
                weightTextBox.Clear();
                originZipTextBox.Clear();
                destinationZipTextBox.Clear();

                //refocuses on the top text box
                originZipTextBox.Focus();

            }

                
        }
        //Precondition: Details must be clicked and a list box item must be selected
        //Postcondition: details of the list box item will be shown in a message box
        private void detailsButton_Click(object sender, EventArgs e)
        {
            int index; //declared int index
            index = packageListBox.SelectedIndex; //index set to the list box's selected index

            if (index >= 0) //Item was selected
            {
                //Displays selected item's length, width, height, weight, origin zip, and destination zip
                // uses GroundPackage's ToString() to show the fields
                MessageBox.Show(groundPackageList[index].ToString());
            }
        }

        private void fromUoflButton_Click(object sender, EventArgs e)
        {
            int index; //declared index
            index = packageListBox.SelectedIndex; //index set to the list box's selected index

            if (index >= 0) //Item was selected
            {
                groundPackageList[index].OriginZip = 40292; //sets the selected index's Origin zipcode to UofL's (40292)

                MessageBox.Show("Origin Zip code has been updated"); //Shows that the update has been set
            }

        }

        private void toUoflButton_Click(object sender, EventArgs e)
        {
            int index; //declared index
            index = packageListBox.SelectedIndex; //index set to the list box's selected index

            if (index >= 0) //Item was selected
            {
                groundPackageList[index].DestinationZip = 40292; //sets the selected index's Destination zipcode to UofL's (40292)
                MessageBox.Show("Destination Zip code has been updated");
            }

        }
    }
}
