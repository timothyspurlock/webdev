﻿/* GradeID: A2598
 * Program 1
 * Due: February 14th 2017
 * CIS-199-01
 * This program gets user input on how much they want to spend
 * on paint, the square feet of wall space to be painted, and 
 * the number of coats of paint they would like to use. The 
 * Program will then calculate and output a total for
 * the square feet, gallons of paint used, amount of 
 * hours of labor it will take, the price of the paint,
 * the price of the labor, and a total of all the prices 
 * summed up. 
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class programOne : Form
    {
        public programOne()
        {
            InitializeComponent();
        }

        const double SQUARE_FEET = 330; // declares square footage for wall constant
        const double LABOR_REQUIRED = 6; // declares required labor for painting constant
        const decimal PRICE_PER_HR = 10.50m; //declares price of labor per hour constant

        private void calculateTotalButton_Click(object sender, EventArgs e)
        {
            double gallonsPaint; // number of gallons used in painting
            double wallSpace; //Amount of wall space by square feet
            double gallonsPaintRounded; // gallon paint used (rounded up)
            double laborHours; // amount of hours of labor it takes 
            decimal laborPrice; // price of the labor
            decimal paintPrice; // price of the total amount of paint
            decimal total; // total of labor and paint price
            int coats; // number of coats used in the paint job
            
            coats = int.Parse(coatsOfPaintTextBox.Text); //takes user input from coats textbox
            gallonsPaint = (float.Parse(wallSpaceTextBox.Text) / SQUARE_FEET) * coats; //calculates number of gallons used by dividing wallspace and SQUARE_FEET then multiplies by coats
            gallonsPaintRounded = Math.Ceiling(gallonsPaint); // rounds up the gallons of paint to the next integer
            wallSpace = double.Parse(wallSpaceTextBox.Text) * coats; //gets user input from wall space text box and times it by coats
            laborHours = (gallonsPaint * LABOR_REQUIRED); // multiplies gallons of paint by the labor required per gallon (6 hours per gallon)
            laborPrice = decimal.Parse(laborHours.ToString("n3")) * PRICE_PER_HR; //Multiplies laborHours (after converted) with Price of labor per hour ( $10.50)
            paintPrice = decimal.Parse(priceOfPaint.Text) * decimal.Parse(gallonsPaintRounded.ToString("n1")); // multiplying price of paint and the rounded amount of gallons
            total = laborPrice + paintPrice; //Calculates total by adding labor price to paint price

            
            sqFtOutput.Text = wallSpace.ToString("n1"); //outputs for wall space
            gallonsOfPaintOutput.Text = gallonsPaintRounded.ToString("n1"); //outputs gallons of paint used
            hoursLaborOutput.Text = laborHours.ToString("n1"); // outputs hours of labor
            priceOfLaborOutput.Text = laborPrice.ToString("c"); // outputs price of labor
            priceOfPaintOutput.Text = paintPrice.ToString("c"); // outputs price of paint
            totalOutput.Text = total.ToString("c"); // outputs price total 
          

        }
    }
}
