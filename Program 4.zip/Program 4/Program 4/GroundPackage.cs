﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    public class GroundPackage
    {
        //Declared default values in case they needed to be changed
        public const double DEFAULT_LENGTH = 1.0D;
        public const double DEFAULT_WIDTH = 1.0D;
        public const double DEFAULT_HEIGHT = 1.0D;
        public const double DEFAULT_WEIGHT = 1.0D;

        //Declared default zip codes
        public const int DEFAULT_ZIPORG = 40202;
        public const int DEFAULT_ZIPDES = 90210;


        //Backing Fields
        private double _length;
        private double _width;
        private double _height;
        private double _weight;
        private int _originZip;
        private int _destintationZip;

        //Constructor
        //Precondition: All values are not empty and are at least > 0.
        //PostCondition: A ground package has been made with specific properties.
        public GroundPackage(double theLength, double theWidth, double theHeight, double theWeight, int theOriginZip, int theDesinationZip)
        {
            Length = theLength;
            Width = theWidth;
            Height = theHeight;
            Weight = theWeight;
            OriginZip = theOriginZip;
            DestinationZip = theDesinationZip;
        }
        //Length Property
        public double Length
        {
            //Precondition: N/A
            //Postcondition: the length has been returned
            get { return _length; }

            //Precondition: value is greater or equal to 1.0
            //Postcondition: the length has been set to a specified value
            set
            {
                if (value >= DEFAULT_LENGTH)
                {
                    _length = value;
                }
                else
                {
                    value = DEFAULT_LENGTH; //if number is invalid, a default value is returned
                }
            }
        }
        //Width Property
        public double Width
        {
            //Precondition: N/A
            //PostCondition: The width has been returned
            get { return _width; }

            //Precondition: value is greater or equal to 1.0
            //PostCondition: The width has been set to a specified value
            set
            {
                if (value >= DEFAULT_WIDTH)
                {
                    _width = value;
                }
                else
                {
                    value = DEFAULT_WIDTH; //if number is invalid, a default value is returned
                }
            }

        }
        //Height Property
        public double Height
        {
            //Precondition: N/A
            //Postcondition: The height has been returned
            get { return _height; }

            //Precondition: Value is greater or equal to 1.0
            //Postcondition: the height has been set to a specified value
            set
            {
                if (value >= DEFAULT_HEIGHT)
                {
                    _height = value;
                }
                else
                {
                    value = DEFAULT_HEIGHT; //if number is invalid, a default value is returned
                }
            }
        }

        //Weight Property
        public double Weight
        {
            //Precondition: N/A
            //Postcondition: the weight has been returned
            get { return _weight; }

            //Precondition: value is greater or equal to 1.0
            //Postcondition: the weight has been set to a specified value
            set
            {
                if (value >= DEFAULT_WEIGHT)
                {
                    _weight = value;
                }
                else
                {
                    value = DEFAULT_WEIGHT; //if number is invalid, a default value is returned
                }
            }
        }
        //Origin Zip Code Property
        public int OriginZip
        {
            //Precondition: N/A
            //Postcondition: the origin zip code has been returned
            get { return _originZip; }

            //Precondition: value is between 10000 and 99999
            //Postcondition: the Origin zip code has been set to a specified value
            set
            {
                if (value >= 10000 && value <= 99999)
                {
                    _originZip = value;
                }
                else
                {
                    value = DEFAULT_ZIPORG; //if number is invalid, a default value is returned
                }
            }
        }
        //Destination Zip Property
        public int DestinationZip
        {
            //Precondition: N/A
            //Postcondition: The destination zip has been returned
            get { return _destintationZip; }

            //Precondition: value is between 10000 and 99999
            //Postcondtion: the destination zip code has been set to a specified value
            set
            {
                if (value >= 10000 && value <= 99999)
                {
                    _destintationZip = value;
                }
                else
                {
                    value = DEFAULT_ZIPDES; //if number is invalid, a default value is returned
                }
            }
        }
        //ZoneDistance Calculation
        public int ZoneDistance
        {
            //Precondition: N/A
            //Postcondition: A calculated distance between both zip codes has been returned
            get
            {
                return Math.Abs((DestinationZip / 1000) - (OriginZip / 10000)); //Calculates the zone distance between both zip codes and makes then positive integers
            }
        }
        //Calculate Cost
        public double CalcCost()
        { 
          //Returns a calculation to get the shipping price for the package
          return (.20) * (Length + Width + Height) + (.5) * (ZoneDistance + 1) * (Weight);
        }

        //public override of ToString to concatenate the properties of the ground package.
        public override string ToString()
        {
            return "Length:" + " " + Length.ToString() + System.Environment.NewLine + "Width:" + " " + Width.ToString() + System.Environment.NewLine + "Height:" + " " + Height.ToString() + System.Environment.NewLine 
                + "Weight:" + " " + Weight.ToString() + System.Environment.NewLine + "Origin Zip:" + " " + OriginZip.ToString("D5") + System.Environment.NewLine + "Destination Zip:" + " " + DestinationZip.ToString("D5");           

               
        }

    }
}
